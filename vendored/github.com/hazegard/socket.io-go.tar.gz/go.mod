module github.com/hazegard/socket.io-go

go 1.24.0

require (
	github.com/NYTimes/gziphandler v1.1.1
	github.com/bytedance/sonic v1.14.1
	github.com/coder/websocket v1.8.14
	github.com/cristalhq/jsn v0.6.0
	github.com/deckarep/golang-set/v2 v2.8.0
	github.com/fatih/structs v1.1.0
	github.com/goccy/go-json v0.10.5
	github.com/gookit/color v1.6.0
	github.com/karagenc/yeast v0.1.1
	github.com/madflojo/testcerts v1.4.0
	github.com/mitchellh/mapstructure v1.5.0
	github.com/quic-go/quic-go v0.55.0
	github.com/quic-go/webtransport-go v0.9.0
	github.com/sasha-s/go-deadlock v0.3.6
	github.com/spf13/pflag v1.0.10
	github.com/stretchr/testify v1.11.1
	github.com/xiegeo/coloredgoroutine v0.1.1
	golang.org/x/term v0.36.0
)

require (
	github.com/bytedance/gopkg v0.1.3 // indirect
	github.com/bytedance/sonic/loader v0.3.0 // indirect
	github.com/cloudwego/base64x v0.1.6 // indirect
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/fatih/color v1.18.0 // indirect
	github.com/klauspost/cpuid/v2 v2.3.0 // indirect
	github.com/kr/text v0.2.0 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/petermattis/goid v0.0.0-20250904145737-900bdf8bb490 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	github.com/quic-go/qpack v0.5.1 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
	go.uber.org/mock v0.6.0 // indirect
	golang.org/x/arch v0.22.0 // indirect
	golang.org/x/crypto v0.43.0 // indirect
	golang.org/x/exp v0.0.0-20240719175910-8a7402abbf56 // indirect
	golang.org/x/mod v0.29.0 // indirect
	golang.org/x/net v0.46.0 // indirect
	golang.org/x/sync v0.17.0 // indirect
	golang.org/x/sys v0.37.0 // indirect
	golang.org/x/text v0.30.0 // indirect
	golang.org/x/tools v0.38.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
